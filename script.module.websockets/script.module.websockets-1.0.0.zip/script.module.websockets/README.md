# script.module.websockets
Python Websockets, repacked for Kodi

https://github.com/x-stride/script.module.websockets/blob/main/addon.xml#:~:text=https%3A//websockets.readthedocs.io/en/stable/intro/index.html%20for%20details
